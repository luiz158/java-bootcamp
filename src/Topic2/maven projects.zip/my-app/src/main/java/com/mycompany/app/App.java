package com.mycompany.app;

import edu.emory.mathcs.backport.java.util.TreeMap;

import java.util.Scanner;

/**
 * Hello world!
 *
 */
public class App 
{
    public static void main( String[] args )
    {
        Scanner in = new Scanner(System.in);
        String string = in.nextLine();
        System.out.println(string);

        TreeMap treeMap = new TreeMap();
        treeMap.put(string, 1);
        System.out.println(treeMap.containsKey(string));
    }
}
